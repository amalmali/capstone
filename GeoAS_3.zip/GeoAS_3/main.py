def main():
    print("Hello from geoas!")


if __name__ == "__main__":
    main()
