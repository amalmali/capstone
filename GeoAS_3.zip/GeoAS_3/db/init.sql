-- تفعيل PostGIS
CREATE EXTENSION IF NOT EXISTS postgis;

-- إنشاء جدول المناطق المحمية
CREATE TABLE IF NOT EXISTS protected_zones (
    id SERIAL PRIMARY KEY,
    name TEXT,
    protection_level INT,
    geom GEOMETRY(Polygon, 4326)
);

-- إدخال البوليقون الجديد (عدّلي الإحداثيات حسب مشروع location_service)
INSERT INTO protected_zones (name, protection_level, geom)
VALUES (
    'Protected Zone A',
    3,
    ST_GeomFromText(
        'POLYGON((
            46.60 24.60,
            46.90 24.60,
            46.90 24.90,
            46.60 24.90,
            46.60 24.60
        ))',
        4326
    )
);
