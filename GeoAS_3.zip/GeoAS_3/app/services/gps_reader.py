import time
import random

class GPSReader:
    def __init__(self, port, baud_rate):
        # في وضع المحاكاة، لا نحتاج لفتح المنفذ الحقيقي
        print(f"🛠️ تم تشغيل محاكي GPS (Port: {port})")

    def read_point(self):
        """إرسال إحداثيات افتراضية لمحاكاة التواجد في الرياض"""
        # يمكنك تغيير هذه القيم لاختبار الدخول والخروج من الـ Geofence
        # إحداثيات افتراضية للرياض
        base_lat = 24.7136
        base_lon = 46.6753
        
        # إضافة تغيير طفيف جداً لمحاكاة الحركة
        lat = base_lat + random.uniform(-0.0001, 0.0001)
        lon = base_lon + random.uniform(-0.0001, 0.0001)
        
        time.sleep(1) # محاكاة تأخير القراءة الحقيقية
        return lat, lon

    def close(self):
        pass